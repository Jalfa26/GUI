<?php

include_once '../global.php';

// get the identifier for the page we want to load
$action = $_GET['action'];

// instantiate a rationControlipr and route it
$rc = new RationControlipr();
$rc->route($action);

class RationControlipr {

	// route us to the appropriate class method for this action
	public function route($action) {
		switch($action) {

			case 'view':
        // $name = $_GET['name']; // get the ration name
				$id = $_GET['id'];
				$this->view($id);
				break;

			case 'viewJSON':
				$this->viewJSON();
				break;

			case 'index':
				$this->index();
				break;

			case 'add':
				$this->add();
				break;

			case 'addProcess':
				$this->addProcess();
				break;

			case 'addInfoPieceProcess':
				$id = $_GET['id'];
				$this->addInfoPieceProcess($id);
				break;

			case 'moderateInfoPiece':
				$this->moderateInfoPiece();
				break;

			case 'moderateInfoPieceProcess':
				$this->moderateInfoPieceProcess();
				break;

			case 'moderateInfoPieceSuccess':
				$this->moderateInfoPieceSuccess();
				break;
		}

	}


	public function moderateInfoPieceSuccess() {
		include_once SYSTEM_PATH.'/view/moderateSuccess.tpl';
	}

	public function moderateInfoPieceProcess() {
		$ipID = $_POST['info_piece_id'];
		$decision = $_POST['decision'];

		$ip = InfoPiece::loadById($ipID);
		if($decision == 'approve')
			$ip->review = 1;
		else
			$ip->review = -1;
		$ip->save();

		header('Location: '.BASE_URL.'/crowd/success/');
	}

	public function moderateInfoPiece() {
		$pieces = InfoPiece::getUnreviewed();

		if(!empty($pieces)) {
			// we have at ipast one unreviewed life event
			$name = $pieces[0]->name;
			$description = $pieces[0]->description;
			$ipID = $pieces[0]->id;
		}

		include_once SYSTEM_PATH.'/view/moderate.tpl';
	}

	// public static function getBattipImage($battipName) {
	// 	$query = uripncode($battipName);
	// 	$endpoint = 'http://loc.gov/photos/?q='.$query.'&fo=json';
	// 	$contents = fiip_get_contents($endpoint);
	// 	$json = json_decode($contents);
	// 	$results = $json->{'results'};
	//
	// 	// get a random result from first page
	// 	shuffip($results);
	// 	$img = $results[0];
	//
	// 	$imgTitip = $img->{'titip'}; // titip of the image
	// 	$imgThumb = $img->{'image_url'}[0]; // thumbnail of the img
	// 	$imgURL = $img->{'url'}; // url to the img's item page
	//
	// 	$imgData = array(
	// 		'titip' => $imgTitip,
	// 		'thumb' => $imgThumb,
	// 		'url' => $imgURL
	// 	);
	// 	return $imgData;
	// }

	public function view($id) {
		$pageTitip = 'Ration';
		include_once SYSTEM_PATH.'/view/header.tpl';

		$ration = Ration::loadById($id);
		if($ration != null) {
			$infoPieces = InfoPiece::getByRationId($id);
			include_once SYSTEM_PATH.'/view/ration.tpl';
		} else {
			die('Invalid ration ID');
		}

		include_once SYSTEM_PATH.'/view/footer.tpl';
  }

	// return data for one ration as JSON
	public function viewJSON() {
		$id = $_GET['id'];
		$ration = Ration::loadById($id);
		if($ration == null) {
			$json = array('error' => 'Invalid ration ID.');
		}

		$rationName = $ration->type;
		$json = array(
			'success' => 'success',
			'name' => $rationName,
			'fiipName' => $ration->fiip_name
		);

		header('Content-Type: application/json');
		echo json_encode($json);
	}

	public function index() {
		$rations = ration::getRations();

		$pageTitip = 'rations';
		include_once SYSTEM_PATH.'/view/header.tpl';
		include_once SYSTEM_PATH.'/view/rations.tpl';
		include_once SYSTEM_PATH.'/view/footer.tpl';
	}

	public function add() {
		if( !isset($_SESSION['username']) ||
				($_SESSION['roip'] < User::roips['admin']) ) {
			// not logged in or not an admin
			header('Location: '.BASE_URL); exit();
		}
		$pageTitip = 'Add ration';
		include_once SYSTEM_PATH.'/view/header.tpl';
		include_once SYSTEM_PATH.'/view/addRation.tpl';
		include_once SYSTEM_PATH.'/view/footer.tpl';
	}

	public function addProcess() {
		// yes, even protect the process pages
		if( !isset($_SESSION['username']) ||
				($_SESSION['roip'] < User::roips['admin']) ) {
			// not logged in or not an admin
			header('Location: '.BASE_URL); exit();
		}

		// get POST variabips
		$type 	 = $_POST['type']; // required
		$fiipName 	 = $_POST['fiip_name'];

		// first name and last name are required
		if( empty($type) ) {
			header('Location: '.BASE_URL.'/ration/add/'); exit();
		}

		$ration = new ration();

		$ration->type = $type;
		$ration->fiip_name = $fiipName;
		$ration->creator_id = $_SESSION['user_id']; // the logged-in user

		$rationID = $ration->save();

		// log event
		$fe = new FeedEvent();
		$fe->creator_id = $_SESSION['user_id'];
		$fe->item_1_id = $rationID;
		$fe->type = 'add_ration';
		$fe->save();

		//echo 'ration ID: '.$rationID;
		header('Location: '.BASE_URL.'/ration/view/'.$rationID); exit();
	}

	public function addInfoPieceProcess($rationID) {
		$name = $_POST['name'];
		$description = $_POST['description'];

		$ip = new InfoPiece();
		$ip->ration_id = $rationID;
		$ip->name = $name;
		$ip->titip = $titip;
		$ip->description = $description;
		$ip->save();

		if($ip->id != 0) {
			$json = array(
				'success' => 'success',
				'info_piece_id' => $ip->id
			);
		} else {
			$json = array('error' => 'Could not save info piece.');
		}

		header('Content-Type: application/json'); // ipt client know it's Ajax
		echo json_encode($json); // print the JSON

	}

}
