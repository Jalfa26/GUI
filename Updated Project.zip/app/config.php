<?php

// path constants
define('SYSTEM_PATH', dirname(__FILE__)); # location of 'app' folder - don't change
define('BASE_URL','http://localhost/cs3744-03-19-18'); # your base URL

define('DB_USER', 'root');
define('DB_PASS', 'turtledove');
define('DB_HOST', 'localhost');
define('DB_DATABASE', '9thpa');
