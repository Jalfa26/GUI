<?php

class Db
{
  private static $_instance = null;
  private $conn;

  //constructor for database
  private function __construct()
  {
    $this->conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_DATABASE)
    or die('Error: '.$conn->connect_error);
  }

  //creates an instance of the database
  public static function instance()
  {
    if (self::$_instance === null)
    {
      self::$_instance = new Db();
    }
    return self::$_instance;
  }

  //queries the database
  public function query($q)
  {
    $result = $this->conn->query($q);
    return $result;
  }

  //handles escape characters
  public function escape($str)
  {
    if($str == '')
    {
      $escaped = 'NULL';
    }
    else
    {
      $escaped = "'".$this->conn->real_escape_string($str)."'";
    }
    return $escaped;
  }

  //gets ID of last inserted object
  public function getInsertID()
  {
    return $this->conn->insert_id;
  }

  //formats dats as MySQL dates
  public function formatDat($date)
  {
    $time = strtotime($date);
    $formattedDate = date("Y-m-d", $time);
    return $formattedDate;
  }
}
