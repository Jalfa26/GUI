$(document).ready(function(){

  $('#addEventButton').click(function(){
    //alert('clicked');
    // console.log("add event clicked");
    $('#addEventForm').show(); // show the form
    $('#eventYear').focus(); // position cursor at event year

    // clear the text boxes
    $('#addEventForm').find('.text').each(function(){
      $(this).val('');
    });
  });

  $('#eventTitle').focus(function(){
    $('#titleThumb').remove(); // clear any existing img
  });

  // event handler for editing event title
  $('#eventTitle').blur(function(){
    var title = $('#eventTitle').val().toLowerCase(); // lowercase for string comparison
    if(title.indexOf('battle') != -1) { // we found the string "battle"
      getBattlePic(title);
    }
  });

  $('#submitEventButton').click(function(){

    // grab the data from the form
    var year = $('#eventYear').val();
    var title = $('#eventTitle').val();
    var details = $('#eventDescription').val();

    // send form data via Ajax
    $.post(
      window.location.href + '/life-event/add/process/',
      {
        year: year,
        title: title,
        details: details
      },
      function(data){
        if(data.success == 'success') {
          // data was saved successfully on the server
          // build the title and details paragraph
          var fullTitle = $('<h4>' + year + ' - ' + title + '</h4>');
          var fullDetails = $('<p class="details">' + details + '</p>');

          // add new content to events list
          $('#events').prepend(fullDetails).prepend(fullTitle);

          // now that we've submitted the form, hide it
          $('#addEventForm').hide();
        } else {
          // server data wasn't saved successfully
          alert('Server error: ' + data.error);
        }
      })
      .fail(function(){
        // the Ajax call failed
        alert("Ajax call failed");
      });
  });


});

function getBattlePic(title) {
  // request the battle picture data via JSONP
  $.ajax({
    url: 'http://loc.gov/photos/',
    jsonpCallback: 'battlepic',
    dataType: 'jsonp',
    data: {
      q: title,
      fo: 'json'
    },

    success: function(response) {
      shuffle(response.results); // randomize results
      var thumb = response.results[0].image_url[0]; // get thumb from JSONP response
      var pic = $('<img id="titleThumb" src="' + thumb + '" alt="' + title + '">'); // create the image element
      $('#eventTitle').parent().append(pic); // attach img to DOM
    }
  });
}

// Shuffle a JS array.
// Source: https://stackoverflow.com/questions/6274339/how-can-i-shuffle-an-array
function shuffle(a) {
    var j, x, i;
    for (i = a.length - 1; i > 0; i--) {
        j = Math.floor(Math.random() * (i + 1));
        x = a[i];
        a[i] = a[j];
        a[j] = x;
    }
}
