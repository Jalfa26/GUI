<?php

include_once '../global.php';

// get the identifier for the page we want to load
$action = $_GET['action'];

// instantiate a rationController and route it
$sc = new RationController();
$sc->route($action);

class RationController {

	// route us to the appropriate class method for this action
	public function route($action) {
		switch($action) {

			case 'view':
        // $name = $_GET['name']; // get the ration name
				$id = $_GET['id'];
				$this->view($id);
				break;

			case 'index':
				$this->index();
				break;

		}

	}

	public function view($id) {
		$pageTitle = 'Ration';
		include_once SYSTEM_PATH.'/view/header.tpl';

		$ration = Ration::loadById($id);
		if($ration != null) {
			$lifeEvents = InfoPiece::getByrationId($id);
			include_once SYSTEM_PATH.'/view/ration.tpl';
		} else {
			die('Invalid ration ID');
		}

		//if($name == 'monshaur')
		//	include_once SYSTEM_PATH.'/view/monshaur.tpl';
		//elseif($name == 'barnes')
		//	include_once SYSTEM_PATH.'/view/barnes.tpl';

		include_once SYSTEM_PATH.'/view/footer.tpl';
  }

	public function index() {
		$rations = Ration::getRations();

		$pageTitle = 'Rations';
		include_once SYSTEM_PATH.'/view/header.tpl';
		include_once SYSTEM_PATH.'/view/rations.tpl';
		include_once SYSTEM_PATH.'/view/footer.tpl';
	}



}
