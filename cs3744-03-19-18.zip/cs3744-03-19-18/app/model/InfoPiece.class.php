<?php

class InfoPiece {
  const DB_TABLE = 'infopiece'; // database table name

  // database fields for this table
  public $id = 0;
  public $description = null;
  public $ration_id =0;
  public $date_created = 0;
  public $name = '';

  // return a Life Event object by ID
  public static function loadById($id) {
      $db = Db::instance(); // create db connection
      // build query
      $q = sprintf("SELECT * FROM `%s` WHERE id = %d;",
        self::DB_TABLE,
        $id
        );
      $result = $db->query($q); // execute query
      // make sure we found something
      if($result->num_rows == 0) {
        return null;
      } else {
        $row = $result->fetch_assoc(); // get results as associative array

        $le = new InfoPiece(); // instantiate new Life Event object

        // store db results in local object
        $le->id           = $row['id'];
        $le->description         = $row['description'];
        $le->ration_id        = $row['ration_id'];
        $le->date_created = $row['date_created'];
        $le->name   = $row['name'];

        return $le; // return the life event
      }
  }

  // return all life events attached to a soldier
  public static function getByRationId($rationID) {
    $db = Db::instance();
    $q = sprintf("SELECT le.id AS InfoPieceID FROM `%s` le
      INNER JOIN `%s` s ON
      le.ration_id = s.id
      WHERE le.ration_id = %d",
      self::DB_TABLE,
      ration::DB_TABLE,
      $rationID
      );
    //echo $q;
    $result = $db->query($q);

    $events = array();
    if($result->num_rows != 0) {
      while($row = $result->fetch_assoc()) {
        $events[] = self::loadById($row['InfoPieceID']);
      }
    }
    return $events;
  }


  public function update() {

  }

}
