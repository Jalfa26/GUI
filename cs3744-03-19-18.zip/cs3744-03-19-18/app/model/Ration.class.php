<?php

class Ration {
  const DB_TABLE = 'rations'; // database table name


  // database fields for this table
  public $id = 0;
  public $name = '';
  public $file_name = null;
  public $date_created = 0;
  public $creator_id = 0;



  // return a name object by ID
  public static function loadById($id) {
      $db = Db::instance(); // create db connection
      // build query
      $q = sprintf("SELECT * FROM `%s` WHERE id = %d;",
        self::DB_TABLE,
        $id
        );
      $result = $db->query($q); // execute query
      // make sure we found something
      if($result->num_rows == 0) {
        return null;
      } else {
        $row = $result->fetch_assoc(); // get results as associative array

        $name = new Ration(); // instantiate new name object

        // store db results in local object
        $name->id           = $row['id'];
        $name->name   = $row['name'];
        $name->file_name    = $row['file_name'];
        $name->date_created = $row['date_created'];
        $name->creator_id   = $row['creator_id'];

        return $name; // return the name
      }
  }

  // return all names as an array
  public static function getRations() {
    $db = Db::instance();
    $q = "SELECT id FROM `".self::DB_TABLE."` ORDER BY name ASC;";
    $result = $db->query($q);

    $names = array();
    if($result->num_rows != 0) {
      while($row = $result->fetch_assoc()) {
        $names[] = self::loadById($row['id']);
      }
    }
    return $names;
  }

  public function save(){
    if($this->id == 0) {
      return $this->insert(); // name is new and needs to be created
    } else {
      return $this->update(); // name already exists and needs to be updated
    }
  }

  public function insert() {
    if($this->id != 0)
      return null; // can't insert something that already has an ID

    $db = Db::instance(); // connect to db
    // build query


    $q = sprintf("INSERT INTO `%s` (`name`, `file_name`, `creator_id`)
    VALUES (%s, %s, %d);",
      self::DB_TABLE,
      $db->escape($this->name),
      $db->escape($this->file_name),
      $db->escape($this->creator_id)
      );
    //echo $q;
    $db->query($q); // execute query
    $this->id = $db->getInsertID(); // set the ID for the new object
    return $this->id;
  }

  public function update() {
    if($this->id == 0)
      return null; // can't update something without an ID

    $db = Db::instance(); // connect to db


    // build query
    $q = sprintf("UPDATE `%s` SET
      `name` = %s,
      `file_name`  = %s,
      `creator_id` = %d
      WHERE `id` = %d;",
      self::DB_TABLE,
      $db->escape($this->name),
      $db->escape($this->file_name),
      $db->escape($this->creator_id),
      $db->escape($this->id)
      );
    $db->query($q); // execute query
    return $db->id; // return this object's ID
  }

}
