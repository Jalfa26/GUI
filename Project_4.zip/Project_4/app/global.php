<?php

session_start(); //starts the user's session

set_include_path(dirname(__FILE__));

include_once 'config.php'; //includes config file

//loads any classes in the specified folder
function __autoload($className)
{
  require_once 'model/'.$className.'.class.php';
}
