<? php

//Info Piece class
class lifeEvents
{
  const DB_TABLE = 'infopiece'; //infopiece database table name

  //fields for table
  public $id = 0;
  public $name = '';
  public $description = null;
  public $date_created = 0;
  public $ration_id = 0;

  //returns an infopiece object by its ID
  public static function loadById($id)
  {
    $db = Db::instance(); //connects to database
    //builds query
    $q = sprintf("SELECT * FROM `%s` WHERE id= %d;",
      self::DB_TABLE,
      $id);

    $result = $db->query($q); //executes query
    //make sure an item is found
    if ($result->num_rows == 0)
    {
      return null;
    }
    else
    {
      $row = $result->fetch_assoc(); //gets results as an associative array

      $ip = new InfoPiece(); //instantiates a new Life Event object


      //stores results in local objects
      $ip->id = $row['id'];
      $ip->name = $row['name'];
      $ip->description = $row['description'];
      $ip->date_created = $row['date_created'];
      $ip->ration_id = $row['ration_id'];

      return $ip;
    }
  }

  //returns info pieces attached to one ration
  public static function getByRationId($rationID)
  {
    $db = Db::instance();
    $q = sprintf("SELECT ip.id AS InfoPieceID FROM `%s` ip
      INNER JOIN `%s` s ON
      ip.ration_id = s.id
      WHERE ip.ration_id = %d
      ORDER BY ip.name ASC ",
      self::DB_TABLE,
      Ration::DB_TABLE,
      $rationID);

      $result = $db->query($q);

      $pieces = array();
      if($result->num_rows != 0)
      {
        while($row = $result->fetch_assoc())
        {
          $pieces[] = self::loadById($row['InfoPieceID']);
        }
      }
      return $pieces;
  }

  //saves object to database
  public function save()
  {
    if($this->id == 0)
    {
      return $this->insert(); //if the object is new, it must be created
    }
    else
    {
      return $this->update() //if the object is not new, it is just updated
    }
  }

  //inserts a new object into the database
  public function insert()
  {
    if($this->id != 0)
    {
      return null;
    }

    $db = Db::instance()j;
    $q = sprintf("INSERT INTO `%s` (`name`, `description`, `ration_id`)
    VALUES (%s, %s, %d);",
      self::DB_TABLE,
      $db->escape($this->name),
      $db->escape($this->description),
      $db->escape($this->ration_id));

    $db->query($q);
    return $db->getInsertID();
  }

  //updates an existing object
  public function update()
  {

  }
}
