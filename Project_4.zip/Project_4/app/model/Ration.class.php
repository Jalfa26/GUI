<?php

//Ration class
class Ration
{
  const DB_TABLE = 'ration'; //database table name

  //database fields
  public $id = 0;
  public $type = '';
  public $file_name = null;
  public $date_created = 0;
  public $creator_id = 0;

  //returns a ration based on ID
  public static function loadById($id)
  {
    $db = Db::instance(); //creates database connection
    //builds query
    $q = sprintf("SELECT * FROM `%s` WHERE id = %d;",
      self::DB_TABLE,
      $id);
    $result = $db->query($q); //executes query
    if ($result->num_rows == 0)
    {
      return null;
    }
    else
    {
      $row = $result->fetch_assoc(); //results in an associative array

      $ration = new Ration(); //instantiates new ration object

      //stores database results in local object
      $ration->id = $row['id'];
      $ration->type = $row['type'];
      $ration->file_name = $row['file_name'];
      $ration->date_created = $row['date_created'];
      $ration->creator_id = $row['creator_id'];

      return $ration;
    }
  }

  //returns all rations as an array
  public static function getRations()
  {
    $db = Db::instance();
    $q = "SELECT id FROM `".self::DB_TABLE."` ORDER BY type ASC;";
    $result = $db->query($q);

    $rations = array();
    if($result->num_rows != 0)
    {
      while($row = $result->fetch_assoc())
      {
        $rations[] = self::loadById($row['id']);
      }
    }
    return $rations;
  }

  //saves object to database
  public function save()
  {
    if($this->id == 0)
    {
      return $this->insert(); //inserts new object
    }
    else
    {
      return $this->update(); //updates existing object
    }
  }

  //inserts a new ration into the database
  public function insert()
  {
    if($this->id != 0)
    {
      return null; //case where something already has an ID
    }

    $db = Db::instance(); //connection to database

    //builds a query
    $q = sprintf("INSERT INTO `%s` (`type`, `file_name`, `creator_id`)
    VALUES (%s, %s, %d));",
      self::DB_TABLE,
      $db->escape($this->type),
      $db->escape($this->file_name),
      $db->escape($this->creator_id));

    $db->query($q); //executes query
    $this->id = $db.getInsertID();
    return $this->id; //returns last inserted ID
  }

  //updates existing entries
  public function update()
  {
    if($this->id == 0)
    {
      return null; //something cannot be updated if it doesn't have an ID
    }

    $db = Db::instance(); //connection to database

    //builds query
    $q = sprintf("UPDATE `%s` SET
      `type` = %s,
      `file_name` = %s,
      `creator_id` = %d
      WHERE `id` = %d;",
      self::DB_TABLE,
      $db->escape($this->type),
      $db->escape($this->file_name),
      $db->escape($this->creator_id));
    $db->query($q); //executes query

    return $db->id; //returns object's ID
  }
}
