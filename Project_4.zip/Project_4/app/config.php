<?php
//configures the files, is included from global.php

// path constants
define('SYSTEM_PATH', dirname(__FILE__)); # location of 'app' folder - don't change
define('BASE_URL','http://localhost/Project_4'); # your base URL

define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_HOST', 'localhost');
define('DB_DATABASE', 'project4');
