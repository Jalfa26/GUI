<?php

include_once '../global.php';

//get identifier for page we want to load for user
$action = $_GET['action'];

//create an instance of SiteController and route it
$sc = new SiteController();
$sc->route($action);

class SiteController
{

	//route the user to the method necessary
	public function route($action)
	{
		switch($action) {
			case 'home':
				$this->home();
				break;

			case 'dashboard':
				$this->dashboard();
				break;

			case 'login':
				$this->login();
				break;

			case 'loginProcess':
				$username = $_POST['username'];
				$password = $_POST['pw'];
				$this->loginProcess($username, $password);
				break;

			case 'logout':
				$this->logoutProcess();
				break;

		}

	}

	//handles the login process - not visible to user
	public function loginProcess($un, $pw)
	{
		$correctUsername = 'rationsproject';
		$correctPassword = 'rationsproject';

		if($un != $correctUsername)
			header('Location: '.BASE_URL);
		elseif($pw != $correctPassword)
			header('Location: '.BASE_URL);
		else {
			$_SESSION['username'] = $un;
			header('Location: '.BASE_URL.'/dashboard'); exit();
		}
	}

	//loads the homepage for the user
  public function home()
	{
		$pageTitle = 'Home';
		include_once SYSTEM_PATH.'/view/home.tpl';
		include_once SYSTEM_PATH.'/view/footer.tpl';
  }

	//loads the dashboard once a user is correctly logged in
	public function dashboard()
	{
		//redirect user if they are not logged in
		if(!isset($_SESSION['username']))
		{
			header('Location: '.BASE_URL); exit();
		}

		$pageTitle = 'Dashboard';
		include_once SYSTEM_PATH.'/view/header.tpl';
		include_once SYSTEM_PATH.'/view/dashboard.tpl';
		include_once SYSTEM_PATH.'/view/footer.tpl';
	}

	//loads the login page
	public function login()
	{
		$pageTitle = 'Login';
		include_once SYSTEM_PATH.'/view/header.tpl';
		include_once SYSTEM_PATH.'/view/login.tpl';
		include_once SYSTEM_PATH.'/view/footer.tpl';
	}

	//takes care of the logout process - invisible to user
	public function logoutProcess()
	{
		unset($_SESSION['username']);
		session_destroy();
		header('Location: '.BASE_URL); exit();
	}


}
