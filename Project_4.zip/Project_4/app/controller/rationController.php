<?php

include_once '../global.php';

//get identifier for page we want to load
$action = $_GET['action'];

//create a RationController instance and route it
$pc = new RationController();
$pc->route($action);

class RationController
{

  //route the user to the class method below based off of redirect from .htaccess
  public function route($action)
  {
    switch($action)
    {
      case 'view':
        //Gets the person's name
        $id = $_GET['id'];
        $this->view($id);
        break;

      case 'list':
        $this->list();
        break;

      case 'add':
        $this->add();
        break;

      case 'addProcess':
        $this->addProcess();
        break;
    }
  }

  //gets the template page for the person requested
  public function view($id)
  {
    $pageTitle = 'Ration';
    include_once SYSTEM_PATH.'/view/header.tpl';

    $ration = Ration::loadById($id);
    if($ration != null)
    {
      $infoPieces = InfoPiece::getByRationId($id);
      include_once SYSTEM_PATH.'/view/ration.tpl';
    }
    else
    {
      die('Invalid ration ID');
    }

    include_once SYSTEM_PATH.'/view/footer.tpl';
  }

  //provides a list of people in the Lannister family
  public function list()
  {
    $rations = Ration::getRations();

    $pageTitle = 'Rations';
    include_once SYSTEM_PATH.'/view/header.tpl';
    include_once SYSTEM_PATH.'/view/rations.tpl';
    include_once SYSTEM_PATH.'/view/footer.tpl';
  }

  public function add()
  {
    $pageTitle = 'Add Ration';
    include_once SYSTEM_PATH.'/view/header.tpl';
    include_once SYSTEM_PATH.'/view/addRation.tpl';
    include_once SYSTEM_PATH.'/view/footer.tpl';
  }

  //behind the scenes function for adding a ration
  public function addProcess()
  {
    //gets POST variables
    $type = $_POST['type'];
    $fileName = $_POST['file_name'];

    //this block is here because a first and last name are required fields
    if( empty($type) )
    {
      header('Location: '.BASE_URL.'./ration/add/'); exit();
    }

    $ration = new Ration();

    $ration->type = $type;
    $ration->file_name = $fileName;
    $ration->creator_id = 1; //hard coded - full functionality is not yet implemented

    $rationID = $ration->save();

    header('Location: '.BASE_URL.'/ration/view/'.$rationID); exit();
  }

}
